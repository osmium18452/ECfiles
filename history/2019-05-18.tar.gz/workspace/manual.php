<?php
require('init.php');
$title = 'Manual';
require(LIBWWWDIR . '/header.php');
?>

<style>
h2 {
	text-align:left;
}
div>p {
	text-indent:0em;
}
</style>
<nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
	<a class="navbar-brand hidden-sm-down" href="./">DOMjudge</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuDefault" aria-controls="menuDefault" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="menuDefault">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active">
				<a class="nav-link" href="manual.php"><span class="octicon octicon-book"></span> Manual</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="environment.php"><span class="octicon octicon-book"></span> Environment</a>
			</li>
		</ul>
	</div>
</nav>

</div><script type="text/javascript">
    var initial = 1557995313;
    var activatetime = 1526457579.000000000;
    var starttime = 1557993579.000000000;
    var endtime = 1565942379.000000000;
    var offset = 0;
    var date = new Date(initial*1000);
    var timeleftelt = document.getElementById("timeleft");

    setInterval(function(){updateClock();},1000);
    updateClock();
</script>
<div style="padding: 40px; border: 1px solid rgb(243, 243, 243); margin-top: -10px; max-width:1100px; margin:auto">
<h1><strong>Summary</strong></h1>
<p>This page gives a short summary of the system interface. The summary is meant as a quick introduction, to be able to start using the system. It is however strongly advised that your team reads the entire document. There are specific details of this contest control system that might become of importance when you run into problems. <strong>BE WARNED!</strong></p>

<p>DOMjudge works through a web interface that can be found at <a href="http://192.168.0.101/domjudge/team/">http://192.168.0.101/domjudge/team</a>. </p>

<h2><strong>Reading and writing</strong></h2>
<p>Solutions have to read all input from ‘standard in’ and write all output to ‘standard out’ (also known as console). You will never have to open (other) files. </p>
<h2><strong>Submitting solutions</strong></h2>
<p>You can submit solutions from the web interface:</p>
<dl>
  <dt>Web interface</dt>
  <dd><p>From your team page, <a href="http://192.168.0.101/domjudge/team/">http://192.168.0.101/domjudge/team</a>, click the green <strong>Submit</strong> button in the menu bar. Select the file(s) you want to submit. By default, the problem is selected from the base of the (first) filename and the language from the extension. The web interface tries to auto-detect the main class (for Java and Kotlin) or the main file (for Python 2 and Python 3) from the file name. Double check that the guess is correct before submitting.</p>
  </dd>
</dl>
<h2><strong>Viewing scores, submissions, etc.</strong></h2>
<p>Viewing scores, submissions and sending and reading clarification requests and replies is done through the web interface at <a href="http://192.168.0.101/domjudge/team/">http://192.168.0.101/domjudge/team</a>.</p>
<p><em>End of summary</em></p>

<h1><strong>Submitting solutions</strong></h1>
<h2><strong>Web interface</strong></h2>
<p>Solutions can be submitted from the web interface at <a href="http://192.168.0.101/domjudge/team/">http://192.168.0.101/domjudge/team</a>. Click the green Submit button at the menu bar on every page. Click the file selection button and select one or multiple files for submission. will try to determine the problem, language and main class (in case of Java and Kotlin) or main file (in case of Python 2 and 3) from the base and extension of the first filename. Otherwise, select the appropriate values. Filenames must start with an alphanumerical character and may contain only alphanumerical characters and .</p>
<p>After you hit the submit button and confirm the submission, you will be redirected back to your submission list page. On this page, a message will be displayed that your submission was successful and the submission should be present in the list. An error message will be displayed if something went wrong.</p>
<h1><strong>Viewing the results of submissions</strong></h1>
<p>The left column of your team web page shows an overview of your submissions. It contains all relevant information: submission time, programming language, problem and status. The address of your team page is <a href="http://192.168.0.101/domjudge/team/">http://192.168.0.101/domjudge/team</a>.</p>
<p>The top of the page shows your team’s row in the scoreboard: your position and which problems you attempted and solved. Via the menu you can view the public scoreboard page with the scores of all teams. Many cells will show additional “title text” information when hovering over them. The score column lists the number of solved problems and the total time including penalty time. Each cell in a problem column lists the number of submissions, and if the problem was solved, the time of the first correct submission in minutes since contest start. This is included in your total time together with any penalty time incurred for previous incorrect submissions. Optionally the scoreboard can be ‘frozen’ some time before the end of the contest. The full scoreboard view will not be updated anymore, but your team row will. Your team’s rank will be displayed as ‘?’. Finally, via the top menu you can also view the list of problems and view/download problem texts and sample data, if provided by the judges.</p>
<h2><strong>Possible results</strong></h2>
<p>A submission can have the following results (not all of these may be available depending on configuration of the system):</p>
<ul>
  <li><dt>CORRECT</dt></li>
  <dd><p>The submission passed all tests: you solved this problem! <em>Correct submissions do not incur penalty time.</em></p>
  </dd>
  <li><dt>COMPILER-ERROR</dt></li>
  <dd><p>There was an error when compiling your program. On the submission details page you can inspect the exact error (this option might be disabled). <strong>Note</strong> that when compilation takes more than  seconds, it is aborted and this counts as a compilation error. <em>Compilation errors do not incur penalty time.</em></p>
  </dd>
  <li><dt>TIMELIMIT</dt></li>
  <dd><p>Your program took longer than the maximum allowed time for this problem. Therefore it has been aborted. This might indicate that your program hangs in a loop or that your solution is not efficient enough.</p>
  </dd>
  <li><dt>RUN-ERROR</dt></li>
  <dd><p>There was an error during the execution of your program. This can have a lot of different causes like division by zero, incorrectly addressing memory (e.g. by indexing arrays out of bounds), trying to use more memory than the limit, etc. Also check that your program exits with exit code 0!</p>
  </dd>
  <li><dt>NO-OUTPUT</dt></li>
  <dd><p>Your program did not generate any output. Check that you write to standard out.</p>
  </dd>
  <li><dt>OUTPUT-LIMIT</dt></li>
  <dd><p>Your program generated more output than the allowed limit. The output was truncated and considered incorrect.</p>
  </dd>
  <li><dt>WRONG-ANSWER</dt></li>
  <dd><p>The output of your program was incorrect. This can happen simply because your solution is not correct, but remember that your output must comply exactly with the specifications of the judges. See section [testing] below for more details.</p>
  </dd>
  <li><dt>TOO-LATE</dt></li>
  <dd><p>Bummer, you submitted after the contest ended! Your submission is stored but will not be processed anymore.</p>
  </dd>
</ul>
<p><strong>Note</strong> that the judges may have prepared multiple test files for each problem. will report back the first incorrect result as verdict.</p>
<h1><strong>Clarifications</strong></h1>
<p>All communication with the judges is to be done through clarifications. These can be found in the right column on your team page. Both clarification replies from the judges and requests sent by you are displayed there.</p>
<p>There is also a button to submit a new clarification request to the judges; you can associate a specific problem or one of the general categories to a request. This clarification request is only readable for the judges. The judges can answer specifically to your team or send a reply to everyone if it is relevant for all.</p>
<h1><strong>How are submissions being judged?</strong></h1>
<p>The contest control system is fully automated. Judging is done in the following way:</p>
<h2><strong>Submitting solutions</strong></h2>
<p>With the web interface (see section [submit]) you can submit a solution to a problem to the judges. <strong>Note</strong> that you have to submit the source code of your program (and not a compiled program or the output of your program).</p>
<p>On the contest control system your program enters a queue, awaiting compilation, execution and testing on one of the autojudges.</p>
<h2><strong>Compilation</strong></h2>
<p>Your program will be compiled on an autojudge machine running Linux. All submitted source files will be passed to the compiler which generates a single program to run. For Java and Kotlin the given main class will be checked; for Python 2 and Python 3 we do a syntax check using the module.</p>
<h2><strong>Testing</strong></h2>
<p>After your program has compiled successfully it will be executed and its output compared to the output of the judges. Before comparing the output, the exit status of your program is checked: if your program exits with a non-zero exit code, the result will be a <span style="font-variant: small-caps;">run-error</span> even if the output of the program is correct! There are some restrictions during execution. If your program violates these it will also be aborted with a <span style="font-variant: small-caps;">run-error</span>, see section [runlimits].</p>
<p>When comparing program output, it has to exactly match to output of the judges, except that some extra whitespace may be ignored (this depends on the system configuration of the problems). So take care that you follow the output specifications. In case of problem statements which do not have unique output (e.g. with floating point answers), the system may use a modified comparison function. This will be documented in the problem description.</p>
<h2><strong>Restrictions</strong></h2>
<p>To prevent abuse, keep the jury system stable and give everyone clear and equal environments, there are some restrictions to which all submissions are subjected:</p>
<ul>
  <li><dt>compile time</dt></li>
  <dd><p>Compilation of your program may take no longer than seconds. After that, compilation will be aborted and the result will be a compile error. In practice this should never give rise to problems. Should this happen to a normal program, please inform the judges right away.</p>
  </dd>
  <li><dt>source size</dt></li>
  <dd><p>The total amount of source code in a single submission may not exceed  kilobytes, otherwise your submission will be rejected.</p>
  </dd>
  <li><dt>memory</dt></li>
  <dd><p>During execution of your program, there are  kilobytes of memory available. This is the total amount of memory (including program code, statically and dynamically defined variables, stack, Java VM, …)! If your program tries to use more memory, it will most likely abort, resulting in a run error.</p>
  </dd>
  <li><dt>number of processes</dt></li>
  <dd><p>You are not supposed to explicitly create multiple processes (threads). This is to no avail anyway, because your program has exactly 1 processor core fully at its disposal. To increase stability of the system, executes submissions in a sandbox where a maximum of  processes can be run simultaneously (including processes that started your program).</p>
  <p>People who have never programmed with multiple processes (or have never heard of “threads”) do not have to worry: a normal program runs in one process.</p>
  </dd>
</ul>
<!--
<h1><strong>Code examples</strong></h1>
<p>Below are a few examples on how to read input and write output for a problem.</p>
<p>The examples are solutions for the following problem: the first line of the input contains the number of testcases. Then each testcase consists of a line containing a name (a single word) of at most 99 characters. For each testcase output the string “Hello <span class="math"> &lt; </span>name<span class="math"> &gt; </span>!” on a separate line.</p>
<p>Sample input and output for this problem:</p>
<table>
  <thead>
	<tr class="header">
	  <th align="left"><strong>Input</strong></th>
	  <th align="left"><strong>Output</strong></th>
	</tr>
  </thead>
  <tbody>
	<tr class="odd">
	  <td align="left"></td>
	  <td align="left"></td>
	</tr>
  </tbody>
</table>
<p><strong>Note</strong> that the number 3 on the first line indicates that 3 testcases follow.</p>
<p>A solution for this problem in C:</p>
<p>A solution in C++:</p>
<p>A solution in Java:</p>
<p>A solution in Python:</p>
<p>A solution in C#:</p>
<p>A solution in Pascal:</p>
<p>And finally a solution in Haskell:</p>
</div>
-->