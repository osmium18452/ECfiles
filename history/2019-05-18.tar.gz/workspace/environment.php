<?php
require('init.php');
$title = 'Manual';
require(LIBWWWDIR . '/header.php');
?>

<style>
h2 {
	text-align:left
}
</style>
<nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
	<a class="navbar-brand hidden-sm-down" href="./">DOMjudge</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuDefault" aria-controls="menuDefault" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="menuDefault">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="manual.php"><span class="octicon octicon-book"></span> Manual</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link" href="environment.php"><span class="octicon octicon-book"></span> Environment</a>
			</li>
		</ul>
	</div>
</nav>

</div><script type="text/javascript">
    var initial = 1557995313;
    var activatetime = 1526457579.000000000;
    var starttime = 1557993579.000000000;
    var endtime = 1565942379.000000000;
    var offset = 0;
    var date = new Date(initial*1000);
    var timeleftelt = document.getElementById("timeleft");

    setInterval(function(){updateClock();},1000);
    updateClock();
</script>
<div style="padding: 40px; border: 1px solid rgb(243, 243, 243); margin-top: -10px; max-width:1100px; margin:auto">
    <div>
        <div>
            <div ><h1><span><strong>The 2019 ACM-ICPC China Xi'an Invitational Programming Contest Environment</strong></span>
            </h1>
                <p>This page describes current plans for the Programming Environment which will be available to each
                    team. &nbsp;Please note that <em><strong>these plans are subject to
                        change</strong></em>. </p>
                <!--
                <h2 ><span>Hardware:</span></h2>
                <p>Each team will be provided with one workstation consisting of the following
                    hardware:</p>
                <ul>
                    <li>HP ProOne 600 G4 21.5 inch FHD Non-Touch All-in-One Business PC
                        <ul>
                            <li>Intel Core i5 8500 3.0 2666MHz 6C 65W CPU</li>
                            <li>16GB DDR4 2666 SODIMM Memory</li>
                            <li>256GB Solid State Drive</li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li>21.5" integrated screen</li>
                    <li>External keyboard: HP model 803181-131. &nbsp;See a keyboard image <span><a target="_blank"
                                                        href="https://icpc.baylor.edu/download/worldfinals/programming-environment/WF2019-Keyboard-Image.jpg">here</a></span>.
                        &nbsp;See <em><strong>important Keyboard Notes</strong></em> <span ><a
                                target="_blank"
                                href="https://icpc.baylor.edu/download/worldfinals/programming-environment/2019KeyboardNotes.pdf">here</a></span>.
                    </li>
                    <li>External mouse: HP model 672654-001 Laser Optical Mouse. &nbsp;See a mouse image <span
                            ><a target="_blank"
                                                        href="https://icpc.baylor.edu/download/worldfinals/programming-environment/WF2019-Mouse-Image.jpg">here</a></span>.
                    </li>
                </ul>
                <p>No hardware substitutions will be allowed (that is, teams may not bring their own equipment onto the
                    contest floor). &nbsp;This includes that teams may not substitute keyboards or other peripherals;
                    all teams will use identical equipment, as described above, during the contest.</p>
                -->
<br><br><br>
                <h2><span><strong>Software:</strong></span></h2>
                <p>The software configuration for the Xi'an Invitational Contest will consist of the following:</p>
                <ul>
                    <li>OS:
                        <ul>
                            <li>Ubuntu 18.04.1 LTS Linux (64-bit)</li>
                        </ul>
                    </li>
                    <li>Desktop:
                        <ul>
                            <li>GNOME</li>
                        </ul>
                    </li>
                    <li>Editors
                        <ul>
                            <li>vi/vim</li>
                            <li>gvim</li>
                            <li>emacs</li>
                            <li>gedit</li>
                            <!--
                            <li>geany</li>
                            <li>kate</li>
                            -->
                        </ul>
                    </li>
                    <li>Languages:
                        <ul>
                            <li>Java
                                <ul>
                                    <li>Openjdk version "10.0.2" 2018-07-17</li>
                                    <li>OpenJDK Runtime Environment (build 10.0.2+13-Ubuntu-1ubuntu0.18.04.2)</li>
                                    <li>OpenJDK 64-Bit Server VM (build 10.0.2+13-Ubuntu-1ubuntu0.18.04.2, mixed mode)
                                    </li>
                                </ul>
                            </li>
                            <li>C
                                <ul>
                                    <li>gcc (Ubuntu 7.3.0-27ubuntu118.04) 7.3.0</li>
                                </ul>
                            </li>
                            <li>C++
                                <ul>
                                    <li>g++ (Ubuntu 7.3.0-27ubuntu118.04) 7.3.0</li>
                                </ul>
                            </li>
                            <li>Python 2
                                <ul>
                                    <li>Python 2.7.13 
                                        <!--(5.10.0+dfsg-3build2, Feb 06 2018, 18:37:50)-->
                                    </li>
                                </ul>
                            </li>
                            <li>Python 3
                                <ul>
                                    <li>
                                        CPython 3.6.6.
                                    </li>
                                </ul>
                            </li>
                            <!--                       
                            <li>Kotlin
                                <ul>
                                    <li>Version 1.2.70-release-54 using JVM as listed above</li>
                                </ul>
                            </li>
                            -->
                        </ul>
                    </li>
                    <li>IDEs:
                        <ul>
                            <li>Eclipse 4.8 (Photon), configured with:
                                <ul>
                                    <li>JDT (Java Development Tools version 3.14.0.v20180611-0500 using Java as listed
                                        above)
                                    </li>
                                    <li>CDT (C/C++ Development Tools version 9.5.2.201807181141 using C/C++ as listed
                                        above)
                                    </li>
                                    <li>PyDev (Python Development Environment version 6.4.3.201807050139 using Python as
                                        listed above)
                                    </li>
                                </ul>
                            </li>
                            <li>IntelliJ (IDEA Community Edition version 2018.2.4), configured with:
                                <ul>
                                    <li>Java as listed above</li>
                                    <li>Kotlin plugin version 1.2.51-release-IJ2018.2-1</li>
                                </ul>
                            </li>
                            <li>CLion (version 2018.2.4), configured with:
                                <ul>
                                    <li>C/C++ as listed above</li>
                                </ul>
                            </li>
                            <li>Pycharm Community Edition Python IDE (version 2018.2.4), configured with:
                                <ul>
                                    <li>Python 3 as listed above</li>
                                </ul>
                            </li>
                            <li>Code::Blocks (version 16.01+dfsg-2.1), configured with:
                                <ul>
                                    <li>C/C++ as listed above</li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
<br><br><br>
                <h2 ><span><strong>Compilation of Submissions:</strong></span></h2>
                <p>During the contest, teams will submit proposed solutions to the contest problems to the Judges using
                    the DOMJudge contest control system. Source files submitted to the Judges will be compiled using the following
                    command line arguments for the respective language:</p>
                <ul>
                    <li>C:</li>
                </ul>
                <blockquote><p><tt>gcc -std=gnu11 -Wall -O2 -static -pipe ${files} -lm</tt></p></blockquote>
                <ul>
                    <li>C++:</li>
                </ul>
                <blockquote><p><tt>g++ -std=c++11 -Wall -O2 -static -pipe ${files}</tt></p></blockquote>
                <ul>
                    <li>Java:</li>
                </ul>
                <blockquote><p><tt>javac -encoding UTF-8 -sourcepath . -d . ${files}</tt></p></blockquote>
                <ul>
                    <li>Python 2</li>
                </ul>
                <blockquote><p><tt>python2 -m py_compile ${files}</tt></p></blockquote>
                <ul>
                    <li>Python 3</li>
                </ul>
                <blockquote><p><tt>python3 -m py_compile ${files}</tt></p></blockquote>
                <!--
                <ul>
                    <li>Kotlin</li>
                </ul>
                <blockquote><p><tt >kotlinc -d . ${files</tt>}</p></blockquote>
                -->
                <p>The "${files}" in the above commands represents the list of source files from the submission which
                    will actually be compiled. Files with the following suffixes (and only files with these suffixes)
                    will be submitted to the compiler:</p>
                <ul>
                    <li>For C submissions: files ending with .c</li>
                    <li>For C++ submissions: files ending with .cc, .cpp, .cxx, or .c++</li>
                    <li>For Java submissions: files ending with .java</li>
                    <li>For Python submissions: files ending with .py</li>
                    <!--
                    <li>For Kotlin submissions: files ending with .kt</li>
                    -->
                </ul>
<br><br><br>
                <h2><span><strong>Execution of Submissions:</strong></span></h2>
                <p>For each language, if the above compilation step is successful then the submission will be executed
                    as follows:</p>
                <ul>
                    <li>For C/C++: &nbsp;the executable file generated by the compiler will be executed to generate the
                        output of the submission.&nbsp;&nbsp;
                    </li>
                </ul>
                <!--
                <ul>
                    <li>For Python 2: the main source file will be executed by the PyPy Python interpreter to generate
                        the output of the submission.
                    </li>
                </ul>
                -->
                <ul>
                    <li>For Python 3: the main source file will be executed by the CPython Python3 interpreter to
                        generate the output of the submission.
                    </li>
                </ul>
                <ul>
                    <li>For Java: the compiled main class will be executed using the following command:</li>
                </ul>
                <blockquote><p><tt >java -Dfile.encoding=UTF-8 -XX:+UseSerialGC -Xss64m -Xms1920m -Xmx1920m</tt></p></blockquote>
                <!--
                <ul>
                    <li>For Kotlin: the compiled main class will be executed using the following command:</li>
                </ul>
                <blockquote><p><tt >kotlin -Dfile.encoding=UTF-8 -J-XX:+UseSerialGC -J-Xss64m
                    -J-Xms1920m -J-Xmx1920m</tt></p></blockquote>
                -->
                <p>Compilation and execution as described above will take place in a "sandbox" on a dedicated judging
                    machine. &nbsp;The judging machine will be as identical as possible to, and at least as powerful as,
                    the machines used by teams. &nbsp;The sandbox will allocate 2GB of memory; the entire program,
                    including its runtime environment, must execute within this memory limit. &nbsp;For interpreted
                    languages (Java, Python) the runtime environment includes the interpreter (that is, the
                    JVM for Java/Kotlin and the Python interpreter for Python).</p>
                <p>The sandbox memory allocation size will be the same for all languages and all contest problems.
                    &nbsp;For Java, the above commands show the stack size and heap size settings which will
                    be used when the program is run in the sandbox.</p>

                <!--
                <h2 ><span>Build Instructions:</span></h2>
                <p>Instructions for building a system identical to what is planned for team use at the World Finals are
                    posted <span ><a target="_blank"
                                                             href="http://pc2.ecs.baylor.edu/wfImageBuilds/icpc2019/ImageBuildInstructions.html">here</a></span>.
                    &nbsp;Please note that <em>the image created by these instructions is a <strong>draft</strong></em>,
                    subject to changes as we approach the World Finals. &nbsp;See the
                    <strong><em>Revised&nbsp;</em></strong> list at the bottom of that page to determine the most recent
                    change date.</p>
                <h2 ><span>Reference Materials:</span></h2>
                <p>These packages will be available on team machines at the World Finals, and will be installed
                    automatically as part of the steps listed under <em>Build Instructions</em>, above.&nbsp;</p>
                <ul>
                    <li>JDK JavaDocs</li>
                    <li>C++ STL docs&nbsp;</li>
                    <li><span ><a target="_blank"
                                                          href="https://icpc.baylor.edu/download/worldfinals/programming-environment/DOMJudge.Team-Manual.WF2019.pdf">DOMJudge Team Guide</a></span>
                    </li>
                    <li>Additional Information:
                        <ul>
                            <li><span ><a target="_blank"
                                                                  href="https://icpc.baylor.edu/download/worldfinals/programming-environment/2019JudgingNotes.pdf">Judging Notes</a></span>
                            </li>
                            <li><span ><a target="_blank"
                                                                  href="https://icpc.baylor.edu/download/worldfinals/programming-environment/2019TechNotes.pdf">Technical Notes</a></span>
                            </li>
                        </ul>
                    </li>
                </ul>
                <p>We welcome all suggestions and comments. &nbsp;This configuration is subject to change until the
                    final update. &nbsp;All questions about the system configuration should be directed to <span
                            ><a
                            href="mailto:clevenger@csus.edu?subject=Contest%20Finals%202012%20Systems%20Question">John Clevenger</a></span>,
                    ICPC Technical Director.</p>
                <h2 ><span>Update History</span></h2>
                <p>March 18, 2019 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated keyboard and mouse
                    information<br>March 13, 2019 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated
                    IntelliJ Java version information; updated Code::Blocks configuration<br>March 9, 2019 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated
                    Kotlin, Eclipse, CLion, PyCharm, Code::Blocks, and IntelliJ version numbers<br>March 9, 2019 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Minor
                    update to Technical Notes to align with notes being distributed to Teams<br>February 27, 2019 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated
                    Judging Notes, Technical Notes, and Python module lists to WF 2019 versions<br>January 31, 2019
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated team hardware specifications; updated DOMJudge manual to
                    WF 2019 version; added clarification on judging process &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>October 4,
                    2018 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Updated &nbsp;language/IDE and hardware
                    information<br>August 8, 2018 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Initial version,
                    cloned from WF 2018 description</p>
                <div><p>&nbsp;</p></div>
                -->
            </div>
        </div>
    </div>
</div>

<?php
require(LIBWWWDIR . '/footer.php');