#!/usr/bin/env bash

ipmap_path='IPMACPATH'
target_path='/etc/netplan/'
target_file='01-network-manager-all.yaml'

macaddr=`ip a | grep 'link/e' | head -1 | awk '{print $2}'| sed -e 's/:/-/g' | tr 'a-z' 'A-Z'`

for i in `cat $ipmap_path | sed -e 's/ //g'`; do
    [[ $i == "{" ]] || [[ $i == "}" ]] && continue
    [[ `echo $i | cut -d\" -f2` == $macaddr ]] && ip=`echo $i | cut -d\" -f4` && break
done

[[ $ip == "" ]] && echo "your mac \`$macaddr' is not found" && exit -1

mkdir -p $target_path
cat > $target_path$target_file << EOF
# Let NetworkMamager manage all devices on this system     
network:     
      version: 2     
      renderer: networkd     
      ethernets:     
        eno1:     
          #dhcp4: no     
          #dhcp6: no     
          addresses: [$ip/24]     
          gateway4:  ${ip%.*}.254
          nameservers:     
            addresses: [202.117.80.2, 202.117.80.3]
        enp2s0:     
          #dhcp4: no     
          #dhcp6: no     
          addresses: [$ip/24]     
          gateway4:  ${ip%.*}.254
          nameservers:     
            addresses: [202.117.80.2, 202.117.80.3]
EOF
while (sleep 60); do
    netplan apply
done
