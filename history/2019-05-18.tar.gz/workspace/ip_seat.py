#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os

dic = {}
for i in os.listdir('seat/'):
    print(i[5:])
    dic[i[5:]] = open('seat/' + i, 'r').read().strip('\n')

print(dic)

sear = {"8":"A","9":"B","7":"C","2":"D","3":"E","4":"F","5":"G","6":"H"}
for i in dic:
    p = i.split('.')
    dic[i] = sear[p[2]] + dic[i][1:]
    print(dic[i])

with open('ip_seat.json', 'w') as f:
    json.dump(dic, f, ensure_ascii=False, indent=4)

