#!/usr/bin/env bash

while (true); do
    pssh -h ./psshsucc -t 3 'killall gdm-session-work'
    sleep 10
done
