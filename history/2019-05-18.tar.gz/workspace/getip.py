#!/usr/bin/env python3
# -*- coding: utf-8 -*-

f = open('iplist', 'w')
for i in range(2, 10):
    for j in range(1, 254):
        print("192.168.{}.{}".format(i,j), file=f)
