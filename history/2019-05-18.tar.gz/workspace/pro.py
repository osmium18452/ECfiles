#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

f = open("NewTeamInfo1.tab", "r")

s = []
for i in f.readlines():
    l = i.split('\t')
    t = l[0] + '\t' + l[3] + "({})".format(l[2])
    s.append(t)

sql = open("exec.sql", "w")

for i in s:
    x = i.replace("\"", "\\\"")
    a, b = x.split('\t')
    print('update team set name="{}" where teamid={};'.format(b if b[0] != '(' else (b[1:-1] + b), x.split('\t')[0]), file=sql)

